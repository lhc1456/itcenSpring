package com.hclim.movein.VO;

import lombok.Data;

@Data
public class AddrCodeVO {
	String code;
	String sido;
	String gugun;
}