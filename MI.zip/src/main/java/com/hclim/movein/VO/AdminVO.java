package com.hclim.movein.VO;

import lombok.Data;

@Data
public class AdminVO {
	String aId;
	String aPw;
	String aName;
}