package com.hclim.movein.VO;

import lombok.Data;

@Data
public class MemberVO {
	String mId;
	String mPw;
	String mName;
	String rrn01;
	String rrn02;
	String addr;
	String dAddr;
	String email01;
	String email02;
	String tel01;
	String tel02;
	String tel03;
	String phone01;
	String phone02;
	String phone03;
	String sigunguCode;
}
