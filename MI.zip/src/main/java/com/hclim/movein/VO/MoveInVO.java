package com.hclim.movein.VO;

import lombok.Data;

@Data
public class MoveInVO {
	int ren;
	String state;
	String beforeAddr;
	String beforedAddr;
	String afterAddr;
	String afterdAddr;
	String mId;
	String sigungu;
}
